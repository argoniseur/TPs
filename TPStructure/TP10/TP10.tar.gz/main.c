#include "rbtree.h"

int main(void){
	RedBlackTree tree = rbtree_create();
	for (int i=0;i<10;i++)
		rbtree_add(&tree,i);
	
	
	FILE* fic = fopen("fichier.dot","w");
	rbtree_export_dot(tree,fic);
	return 0;
}
