#include <stdio.h>
#include <string.h>

/* *** PLACER VOS FONCTIONS "UTILITAIRES" ICI *** */

/* Exemple : */

void print_ip_v4(unsigned char ip_addr[4]) {

    printf("%d.%d.%d.%d\n", ip_addr[0], ip_addr[1], ip_addr[2], ip_addr[3]);
}
