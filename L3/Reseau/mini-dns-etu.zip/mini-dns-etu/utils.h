#ifndef __UTILS_H__
#define __UTILS_H__

/* *** PLACER VOS FONCTIONS "UTILITAIRES" ICI *** */

/* Exemple : */

void print_ip_v4(unsigned char ip_addr[4]);


#endif
