#ifndef __TEST_FWD_H__
#define __TEST_FWD_H__

#include "router.h"

/* Init full routing table according to topology t3.txt */
void init_full_routing_table(routing_table_t *rt);

#endif
