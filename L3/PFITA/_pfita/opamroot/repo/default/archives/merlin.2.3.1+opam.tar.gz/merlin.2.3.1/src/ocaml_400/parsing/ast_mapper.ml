(** merlin: manage all internal state *)

type cache = unit

let new_cache () = ()
let cache = ref ()
