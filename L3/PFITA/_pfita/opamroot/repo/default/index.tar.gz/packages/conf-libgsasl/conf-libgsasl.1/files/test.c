#include <gsasl.h>

void test(void) {
  Gsasl *ctx = NULL;
  gsasl_init (&ctx);
}
